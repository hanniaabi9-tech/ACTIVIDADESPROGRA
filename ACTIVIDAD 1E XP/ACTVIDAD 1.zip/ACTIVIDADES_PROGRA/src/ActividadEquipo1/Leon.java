package ActividadEquipo1;

public class Leon extends Animal {

    public Leon() {
        super("León");
    }

    @Override
    public String hacerRuido() {
        return "¡Groaar!";
    }
}