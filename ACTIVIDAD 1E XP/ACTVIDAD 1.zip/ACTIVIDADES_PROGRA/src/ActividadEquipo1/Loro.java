package ActividadEquipo1;

public class Loro extends Animal {

    public Loro() {
        super("Loro");
    }

    @Override
    public String hacerRuido() {
        return "¡Hola hola!";
    }
}