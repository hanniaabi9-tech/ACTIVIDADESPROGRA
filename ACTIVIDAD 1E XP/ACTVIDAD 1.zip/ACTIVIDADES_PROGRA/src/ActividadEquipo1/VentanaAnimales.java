package ActividadEquipo1;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class VentanaAnimales extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtPantalla;
    private JComboBox<String> cmbAnimales;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    VentanaAnimales frame = new VentanaAnimales();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public VentanaAnimales() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 320);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // --- TÍTULO ---
        JLabel lblTitulo = new JLabel("Actividad Equipo");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitulo.setBounds(30, 11, 300, 30);
        contentPane.add(lblTitulo);

        // --- MINI PANTALLA (parte superior) ---
        txtPantalla = new JTextField();
        txtPantalla.setEditable(false);
        txtPantalla.setFont(new Font("Arial", Font.BOLD, 16));
        txtPantalla.setHorizontalAlignment(JTextField.CENTER);
        txtPantalla.setBounds(30, 60, 420, 60);
        contentPane.add(txtPantalla);

        // --- MENÚ DESPLEGABLE ---
        JLabel lblElegir = new JLabel("Elija el animal:");
        lblElegir.setFont(new Font("Arial", Font.PLAIN, 14));
        lblElegir.setBounds(30, 150, 150, 25);
        contentPane.add(lblElegir);

        cmbAnimales = new JComboBox<String>();
        cmbAnimales.setFont(new Font("Arial", Font.PLAIN, 14));
        cmbAnimales.setBounds(180, 150, 270, 25);
        cmbAnimales.addItem("León");
        cmbAnimales.addItem("Mono");
        cmbAnimales.addItem("Loro");
        contentPane.add(cmbAnimales);

        // --- BOTÓN HACER RUIDO ---
        JButton btnRuido = new JButton("¡Hacer ruido!");
        btnRuido.setFont(new Font("Arial", Font.PLAIN, 14));
        btnRuido.setBounds(180, 200, 270, 35);
        contentPane.add(btnRuido);

        btnRuido.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // POLIMORFISMO: variable padre, objeto hijo según selección
                Animal animalSeleccionado = null;
                String seleccion = (String) cmbAnimales.getSelectedItem();

                if (seleccion.equals("León")) {
                    animalSeleccionado = new Leon();
                } else if (seleccion.equals("Mono")) {
                    animalSeleccionado = new Mono();
                } else if (seleccion.equals("Loro")) {
                    animalSeleccionado = new Loro();
                }

                if (animalSeleccionado != null) {
                    txtPantalla.setText(animalSeleccionado.hacerRuido());
                }
            }
        });
    }
}