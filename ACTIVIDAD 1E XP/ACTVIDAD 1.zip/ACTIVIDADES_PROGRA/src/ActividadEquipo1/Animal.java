package ActividadEquipo1;

public abstract class Animal {
    protected String nombre;

    public Animal(String nombre) {
        this.nombre = nombre;
    }

    // Ahora regresa String para poder enviarlo a la pantalla
    public abstract String hacerRuido();

    public String getNombre() {
        return nombre;
    }
}