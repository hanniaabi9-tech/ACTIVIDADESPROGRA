package ActividadEquipo1;

public class Mono extends Animal {

    public Mono() {
        super("Mono");
    }

    @Override
    public String hacerRuido() {
        return "¡uu aa, uu aa!";
    }
}